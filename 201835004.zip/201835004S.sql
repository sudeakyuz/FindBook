create database _201835004
use _201835004
create table Users(
id int Primary Key identity(1,1),
username varchar(50),
password varchar(250)
)
create table Books(
id int Primary Key identity(1,1),
name varchar(250),
writer varchar(250),
publisher varchar(250))

insert into Books (name,writer,publisher) values('Hamlet','Sheakspeare','Star'),
                                               ('Crime and Punishment','Dostoyevski','Skyfall'),
											   ('Love and Pride','Jane Austen','Collectors'),
											   ('The Castle','Franz Kafka','Penguin'),
											   ('Amok','Stefan Zweig','Blue'),
											   ('K�rk Mantolu Madonna','Sabahattin Ali','�� Bankas�'),
											   ('Sevda S�zleri','Cemal S�reya','Can'),
											   ('It','Stephen King','Collectors'),
											   ('Kuyucakl� Yusuf','Sabahattin Ali','�� Bankas�'),
											   ('1984','George Orwell','Can'),
											   ('The Stranger','Albert Camus','Star'),
											   ('The Fall','Albert Camus','Star'),
											   ('The Unexpected Guest','Agatha Christie','Fall'),
											   ('Sugar Orange','Vasconcelos','Daisy'),
											   ('�i�ek Senfonisi','�zdemir Asaf','�� Bankas�');


insert into Users(username,password) values('Sude2','1234')
insert into Users(username,password) values('Sude','123')
select * from Books

